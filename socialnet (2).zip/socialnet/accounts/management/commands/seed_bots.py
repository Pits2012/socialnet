import random

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from accounts.models import Profile

BOTS = [
    ('mariia_travels', 'Подорожі, кава та шукаю найкращі схід сонця 🌅'),
    ('deniskitchen', 'Готую те, чого нема в рецептах. Кухар-самоучка 🍳'),
    ('oleh_runs', 'Біжу вранці, думаю ввечері. Марафонець-початківець 🏃'),
    ('kate_draws', 'Малюю скетчі міста, яке люблю ✏️'),
    ('techwithtaras', 'Гаджети, код і трохи філософії 💻'),
    ('yulia_books', 'Читаю більше, ніж сплю. Книжковий блогер 📚'),
    ('maksym_photo', 'Вулична фотографія та довгі прогулянки 📷'),
    ('anna_plants', 'Городні рослини на підвіконні і трохи хаосу 🌿'),
    ('ivan_music', 'Гітара, вініл і безкінечні плейлисти 🎸'),
    ('sofia_fit', 'Тренування, звички, дисципліна. По трохи щодня 💪'),
]


class Command(BaseCommand):
    help = 'Створює набір AI-акаунтів (ботів), які потім можуть публікувати пости.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--password', type=str, default=None,
            help='Пароль для ботів (якщо не вказано — згенерується випадковий, недоступний для входу як звичайний логін не потрібен).'
        )

    def handle(self, *args, **options):
        password = options['password'] or User.objects.make_random_password()
        created_count = 0

        for username, bio in BOTS:
            user, created = User.objects.get_or_create(
                username=username,
                defaults={'email': f'{username}@bots.local'},
            )
            if created:
                user.set_password(password)
                user.save()
                created_count += 1

            profile = user.profile
            profile.bio = bio
            profile.is_bot = True
            # Стабільний випадковий аватар за іменем користувача
            seed = abs(hash(username)) % 70
            profile.avatar_url = f'https://i.pravatar.cc/300?img={seed % 70}'
            profile.save()

        self.stdout.write(self.style.SUCCESS(
            f'Готово. Створено нових ботів: {created_count}. Усього ботів: {len(BOTS)}.'
        ))
