document.addEventListener('DOMContentLoaded', () => {

    // ---------- 1. Reveal-анімація карток при появі у в'юпорті ----------
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });

    function observeReveals(root) {
        root.querySelectorAll('.reveal:not(.in-view)').forEach((el) => revealObserver.observe(el));
    }
    observeReveals(document);

    // ---------- 2. AJAX-лайк з анімацією серця ----------
    document.body.addEventListener('submit', async (e) => {
        const form = e.target;
        if (!form.classList.contains('like-form')) return;
        e.preventDefault();

        const btn = form.querySelector('button');
        const countEl = btn.querySelector('.like-count');
        const csrfInput = form.querySelector('[name=csrfmiddlewaretoken]');

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRFToken': csrfInput ? csrfInput.value : '',
                },
            });
            if (!response.ok) throw new Error('Помилка мережі');
            const data = await response.json();

            btn.classList.toggle('liked', data.liked);
            if (countEl) countEl.textContent = data.count;

            if (data.liked) {
                btn.classList.remove('pulse');
                void btn.offsetWidth; // рестарт анімації
                btn.classList.add('pulse');
            }
        } catch (err) {
            // якщо щось пішло не так — звичайний сабміт форми як запасний варіант
            form.submit();
        }
    });

    // ---------- 3. Нескінченне гортання стрічки ----------
    const postList = document.getElementById('post-list');
    const sentinel = document.getElementById('scroll-sentinel');

    if (postList && sentinel) {
        let nextPage = parseInt(sentinel.dataset.nextPage || '2', 10);
        let loading = false;
        let hasMore = true;

        const scrollObserver = new IntersectionObserver(async (entries) => {
            if (!entries[0].isIntersecting || loading || !hasMore) return;

            loading = true;
            sentinel.classList.add('loading');

            try {
                const resp = await fetch(`/api/posts/?page=${nextPage}`, {
                    headers: { 'X-Requested-With': 'XMLHttpRequest' },
                });
                const data = await resp.json();

                if (data.html && data.html.trim()) {
                    postList.insertAdjacentHTML('beforeend', data.html);
                    observeReveals(postList);
                }

                hasMore = data.has_next;
                nextPage = data.next_page || nextPage + 1;

                if (!hasMore) {
                    sentinel.outerHTML = '<p class="feed-end">Це всі пости. Загляньте пізніше 👋</p>';
                }
            } catch (err) {
                hasMore = false;
            } finally {
                sentinel.classList && sentinel.classList.remove('loading');
                loading = false;
            }
        }, { rootMargin: '600px 0px' });

        scrollObserver.observe(sentinel);
    }
});
