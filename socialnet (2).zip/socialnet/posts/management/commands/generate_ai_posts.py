import os
import random

import requests
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand, CommandError

from posts.models import Post

ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages'
MODEL = 'claude-sonnet-4-6'

TOPICS = [
    'ранкова кава', 'подорож у гори', 'новий рецепт', 'вечірня пробіжка',
    'книга, яку зараз читаю', 'вулична фотографія', 'домашні рослини',
    'нова музика', 'тренування', 'прогулянка містом', 'кіт на підвіконні',
    'захід сонця', 'нотатки з ноутбука', 'ремонт велосипеда', 'дощовий день',
]

SYSTEM_PROMPT = (
    "Ти пишеш короткі, живі підписи до постів у соціальній мережі українською мовою. "
    "Пиши від першої особи, неформально, як звичайна людина, 1-3 речення, "
    "можна 1-2 доречні емодзі, без хештегів у надлишку (максимум 2). "
    "Не додавай лапки навколо тексту і жодних пояснень — лише сам підпис."
)

# Запасний банк підписів — використовується, якщо ANTHROPIC_API_KEY не заданий
# або запит до API не вдався. Завдяки цьому боти постять одразу "з коробки",
# без обов'язкового налаштування API-ключа.
FALLBACK_CAPTIONS = {
    'ранкова кава': [
        'Перша кава ще нікого не підводила ☕ Хорошого дня всім!',
        'Ранок без кави — це просто ще одна ніч 😄',
    ],
    'подорож у гори': [
        'Тиша в горах лікує краще за будь-яку відпустку 🏔️',
        'Ще один перевал позаду. Ноги болять, душа щаслива.',
    ],
    'новий рецепт': [
        'Спробував новий рецепт — вийшло навіть краще, ніж очікував 🍲',
        'Готую те, чого нема в жодній кулінарній книзі.',
    ],
    'вечірня пробіжка': [
        'Вечірня пробіжка — найкращий спосіб вимкнути голову на 30 хвилин 🏃',
        '5 км по парку і думки нарешті стали на місце.',
    ],
    'книга, яку зараз читаю': [
        'Ця книга краде в мене сон уже третю ніч поспіль 📖',
        'Іноді одна фраза з книги важить більше за весь день.',
    ],
    'вулична фотографія': [
        'Місто виглядає інакше, коли просто йдеш і дивишся 📷',
        'Найкращі кадри трапляються, коли не шукаєш їх спеціально.',
    ],
    'домашні рослини': [
        'Ще один листочок на моєму підвіконному лісі 🌿',
        'Рослини не брешуть — якщо їм добре, це видно одразу.',
    ],
    'нова музика': [
        'Знайшов альбом, який тепер на репіті вже другий день 🎧',
        'Іноді пісня просто влучає в настрій day-1.',
    ],
    'тренування': [
        'Не найкраще тренування в моєму житті, але я прийшов — і це вже перемога 💪',
        'Маленькі кроки щодня роблять більше, ніж один ідеальний ривок.',
    ],
    'прогулянка містом': [
        'Вийшов на 10 хвилин, повернувся через дві години 🚶',
        'Іноді найкращий план — це взагалі без плану.',
    ],
    'кіт на підвіконні': [
        'Мій кіт офіційно контролює половину квартири 🐱',
        'Він просто лежить на сонці і виглядає розумнішим за мене.',
    ],
    'захід сонця': [
        'Небо сьогодні явно намагалося справити враження 🌅',
        'Зупинився на хвилину, щоб просто подивитися. Того варто було.',
    ],
    'нотатки з ноутбука': [
        'Ідея, яку записав о 2 ночі, виявилась не такою поганою 💻',
        'День почався з чорнового плану і закінчився зовсім іншим результатом.',
    ],
    'ремонт велосипеда': [
        'Полагодив велосипед власними руками — маленька, але приємна перемога 🔧',
        'Дещо в гаражі, дещо в YouTube-уроках — і ось він знову їде.',
    ],
    'дощовий день': [
        'Дощ за вікном і гаряча кава в руках — це майже ідеальний день ☔',
        'Іноді найкраще, що можна зробити — це нікуди не поспішати.',
    ],
}


class Command(BaseCommand):
    help = (
        'Генерує пости від імені AI-ботів (створених командою seed_bots). '
        'Якщо задано ANTHROPIC_API_KEY — тексти пише модель Claude через API. '
        'Якщо ключа немає — використовується вбудований банк підписів, '
        'тож команда працює одразу, без додаткового налаштування.'
    )

    def add_arguments(self, parser):
        parser.add_argument('--count', type=int, default=5, help='Скільки постів згенерувати.')
        parser.add_argument(
            '--with-images', action='store_true',
            help='Додати до постів випадкові тематичні зображення (picsum.photos).'
        )

    def handle(self, *args, **options):
        api_key = os.environ.get('ANTHROPIC_API_KEY')
        use_ai = bool(api_key)

        if not use_ai:
            self.stdout.write(self.style.WARNING(
                'ANTHROPIC_API_KEY не задано — використовую вбудований банк текстів '
                '(без звернення до Claude API). Щоб боти писали унікальні пости '
                'через AI, задай змінну середовища ANTHROPIC_API_KEY і запусти знову.'
            ))

        bots = list(User.objects.filter(profile__is_bot=True))
        if not bots:
            raise CommandError(
                'Немає жодного бота. Спочатку виконай: python manage.py seed_bots'
            )

        count = options['count']
        with_images = options['with_images']
        created = 0

        for _ in range(count):
            author = random.choice(bots)
            topic = random.choice(TOPICS)

            text = self._generate_text(api_key, topic) if use_ai else None
            if not text:
                text = random.choice(FALLBACK_CAPTIONS[topic])

            post = Post(author=author, text=text)
            if with_images:
                seed = random.randint(1, 100000)
                post.image_url = f'https://picsum.photos/seed/{seed}/800/600'
            post.save()
            created += 1
            self.stdout.write(f'  + {author.username}: {text[:60]}')

        self.stdout.write(self.style.SUCCESS(f'Створено постів: {created}/{count}'))

    def _generate_text(self, api_key, topic):
        try:
            response = requests.post(
                ANTHROPIC_API_URL,
                headers={
                    'x-api-key': api_key,
                    'anthropic-version': '2023-06-01',
                    'content-type': 'application/json',
                },
                json={
                    'model': MODEL,
                    'max_tokens': 150,
                    'system': SYSTEM_PROMPT,
                    'messages': [
                        {'role': 'user', 'content': f'Тема поста: {topic}'}
                    ],
                },
                timeout=30,
            )
            response.raise_for_status()
            data = response.json()
            parts = [b['text'] for b in data.get('content', []) if b.get('type') == 'text']
            return ''.join(parts).strip()
        except requests.RequestException as exc:
            self.stderr.write(self.style.WARNING(f'Помилка запиту до Anthropic API: {exc}. Використовую запасний варіант.'))
            return None
