from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.template.loader import render_to_string

from accounts.models import Follow
from .forms import PostForm, CommentForm
from .models import Post, Like

POSTS_PER_PAGE = 6


def _is_ajax(request):
    return request.headers.get('X-Requested-With') == 'XMLHttpRequest'


@login_required
def feed_view(request):
    """Головна стрічка — як в Instagram: усі пости в реальному часі,
    з можливістю нескінченного гортання (перша сторінка рендериться
    одразу, наступні підвантажуються через /api/posts/)."""
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            messages.success(request, 'Пост опубліковано.')
            return redirect('feed')
    else:
        form = PostForm()

    posts_qs = Post.objects.select_related('author', 'author__profile')
    paginator = Paginator(posts_qs, POSTS_PER_PAGE)
    page = paginator.get_page(1)

    return render(request, 'posts/feed.html', {
        'form': form,
        'page_obj': page,
        'has_next': page.has_next(),
    })


@login_required
def api_posts_view(request):
    """JSON endpoint для нескінченного гортання стрічки."""
    page_number = request.GET.get('page', 1)
    posts_qs = Post.objects.select_related('author', 'author__profile')
    paginator = Paginator(posts_qs, POSTS_PER_PAGE)
    page = paginator.get_page(page_number)

    html = render_to_string('posts/_post_list.html', {
        'page_obj': page,
    }, request=request)

    return JsonResponse({
        'html': html,
        'has_next': page.has_next(),
        'next_page': page.next_page_number() if page.has_next() else None,
    })


@login_required
def following_feed_view(request):
    """Класична стрічка лише від тих, на кого підписаний користувач."""
    following_ids = Follow.objects.filter(follower=request.user).values_list(
        'following_id', flat=True
    )
    posts = Post.objects.filter(
        author_id__in=list(following_ids) + [request.user.id]
    ).select_related('author', 'author__profile')
    return render(request, 'posts/following_feed.html', {'posts': posts})


@login_required
def explore_view(request):
    """Всі пости (не тільки підписки) — для пошуку нових людей."""
    posts = Post.objects.exclude(author=request.user).select_related(
        'author', 'author__profile'
    )
    return render(request, 'posts/explore.html', {'posts': posts})


@login_required
def post_detail_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    comments = post.comments.select_related('author')

    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.post = post
            comment.author = request.user
            comment.save()
            return redirect('post_detail', pk=pk)
    else:
        form = CommentForm()

    return render(request, 'posts/post_detail.html', {
        'post': post, 'comments': comments, 'form': form,
    })


@login_required
def toggle_like_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    like, created = Like.objects.get_or_create(post=post, user=request.user)
    liked = True
    if not created:
        like.delete()
        liked = False

    if _is_ajax(request):
        return JsonResponse({'liked': liked, 'count': post.likes_count})

    next_url = request.POST.get('next') or request.GET.get('next') or 'feed'
    return redirect(next_url)


@login_required
def delete_post_view(request, pk):
    post = get_object_or_404(Post, pk=pk, author=request.user)
    if request.method == 'POST':
        post.delete()
        messages.success(request, 'Пост видалено.')
    return redirect('feed')
