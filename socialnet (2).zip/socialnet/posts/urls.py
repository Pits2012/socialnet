from django.urls import path

from . import views

urlpatterns = [
    path('', views.feed_view, name='feed'),
    path('api/posts/', views.api_posts_view, name='api_posts'),
    path('following/', views.following_feed_view, name='following_feed'),
    path('explore/', views.explore_view, name='explore'),
    path('post/<int:pk>/', views.post_detail_view, name='post_detail'),
    path('post/<int:pk>/like/', views.toggle_like_view, name='toggle_like'),
    path('post/<int:pk>/delete/', views.delete_post_view, name='delete_post'),
]
